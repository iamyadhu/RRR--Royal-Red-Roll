﻿
using UnityEngine;

public class IsTrigger2 : MonoBehaviour
{
    public GameManager gameManager2;
  

     void OnTriggerEnter()
    {
       gameManager2.collectCoins();
    }

}
