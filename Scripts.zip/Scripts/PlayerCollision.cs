﻿using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public Movement movement;

    void OnCollisionEnter(Collision collisionInfo){

        // Obstacles
        if(collisionInfo.collider.tag == "Obstacles")
        {
            movement.enabled = false; // To seize the motion
            FindObjectOfType<GameManager>().EndGame(); //To Restart the game after it touches the Obstacles
        }
        // Friendly Objects
        if(collisionInfo.collider.tag == "Friendly")
        {
            movement.enabled = true; // Doesnt stop the motion
        }
        
      

    }
}
