﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class Credits : MonoBehaviour
{
    public void quit(){

        SceneManager.LoadScene(0); 
    }
    
}
