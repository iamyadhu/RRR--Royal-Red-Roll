﻿using UnityEngine;

public class Player : MonoBehaviour
{
    public Transform player;
    public Vector3 offset;
    // Update is called once per frame
    void Update()
    {
        //Camera to Follow the Player
        transform.position = player.position + offset; 
    }
}
