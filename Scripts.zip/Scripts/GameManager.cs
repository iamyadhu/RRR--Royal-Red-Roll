﻿using UnityEngine;
using UnityEngine.SceneManagement; // To get access to other scenes

public class GameManager : MonoBehaviour
{
    bool gameHasEnded = false;

    public float restartDelay = 1f;

    public GameObject completeLevelUI;
    public GameObject collectCoinsUI;
    public Movement movement;

    public void completeLevel(){

        completeLevelUI.SetActive(true);
        movement.enabled = false;

    }
    
    public void collectCoins(){

        collectCoinsUI.SetActive(true);


    }

    public void EndGame(){

        if(gameHasEnded == false) // To check whether th game has already ended
        {
            gameHasEnded = true;
            Debug.Log("Game Over");
            Invoke("RestartGame",restartDelay); 
            //Invoke is used to call the function after a certain delay

        }
    
 }
    void RestartGame(){

        SceneManager.LoadScene(SceneManager.GetActiveScene().name);    
        // Loads the active scene. GetActiveScene().name gives the name of the current scene.
        // LoadScene loads the name it gets. 
    }

}
