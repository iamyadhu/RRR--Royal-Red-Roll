﻿using UnityEngine;

public class Movement : MonoBehaviour
{

    public Rigidbody rb;
    // Start is called before the first frame update
    public float forwardForce = 2000f;
    public float sidewaysForce = 500f;

    // Update which is called once per frame
    void FixedUpdate()
    {
        //Forward Force
        rb.AddForce(0,0,forwardForce * Time.deltaTime);

        //For Moving Right using D key
        if(Input.GetKey("d"))
        {
            rb.AddForce(sidewaysForce * Time.deltaTime,0,0, ForceMode.VelocityChange);
        }
        //For Moving Left using A key
        if(Input.GetKey("a"))
        {
            rb.AddForce(-sidewaysForce * Time.deltaTime,0,0,ForceMode.VelocityChange);
        }
        // To end the game if it falls below 2 units
        if(rb.position.y < -10f){
            FindObjectOfType<GameManager>().EndGame();

        } 
        
    }
}
