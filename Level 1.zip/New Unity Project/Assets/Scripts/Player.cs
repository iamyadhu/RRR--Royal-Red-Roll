﻿using UnityEngine;

public class Player : MonoBehaviour
{
    public Transform player;
    public Vector3 offset;
    // Update is called once per frame
    void Update()
    {
        //For Following the Player
        transform.position = player.position + offset; 
    }
}
