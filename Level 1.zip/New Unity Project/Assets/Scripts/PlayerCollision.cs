﻿using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public Movement movement;

    void OnCollisionEnter(Collision collisionInfo){

        if(collisionInfo.collider.tag == "Obstacles")
        {
            movement.enabled = false;
            FindObjectOfType<GameManager>().EndGame(); 
        }

        if(collisionInfo.collider.tag == "Friendly")
        {
            movement.enabled = true;
        }
        if(collisionInfo.collider.tag == "Finish")
        {
            movement.enabled = false;

        }

      

    }
}
