﻿using UnityEngine;

public class IsTrigger : MonoBehaviour
{
    public GameManager gameManager;
  

     void OnTriggerEnter()
    {
        gameManager.completeLevel();
    }
}
